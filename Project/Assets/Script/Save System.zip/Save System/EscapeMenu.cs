using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EscapeMenu : MonoBehaviour
{
    [SerializeField] private GameObject go_BaseUI; // �Ͻ� ���� UI �г�
    [SerializeField] private SaveFile theSave;
    [SerializeField] private LoadFile theLoad;
    private PlayerController player;

    private void Start()
    {
        player = GameObject.FindObjectOfType<PlayerController>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (!GameManager.isPause)
                CallMenu();
            else
                CloseMenu();
        }
    }

    private void CallMenu()
    {
        GameManager.isPause = true;
        go_BaseUI.SetActive(true);
        Time.timeScale = 0f; // �ð��� �帧 ����. 0���. �� �ð��� ����.
        player.enabled = false;
    }

    private void CloseMenu()
    {
        GameManager.isPause = false;
        go_BaseUI.SetActive(false);
        Time.timeScale = 1f; // 1��� (���� �ӵ�)
        player.enabled = true;
    }

    public void ClickSave()
    {
        Debug.Log("���̺�");
        theSave.SaveData();
    }

    public void ClickLoad()
    {
        Debug.Log("�ε�");
        theLoad.LoadData();
    }
}
